const express = require('express');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { sendRconCommand } = require('./lib/rcon');

// Basit .env yükleyici: ekstra paket gerektirmez.
const envPath = path.join(__dirname, '.env');
if (fs.existsSync(envPath)) {
  for (const line of fs.readFileSync(envPath, 'utf8').split(/\r?\n/)) {
    if (!line || line.trim().startsWith('#')) continue;
    const eq = line.indexOf('=');
    if (eq === -1) continue;
    const key = line.slice(0, eq).trim();
    const value = line.slice(eq + 1).trim();
    if (!process.env[key]) process.env[key] = value;
  }
}

const app = express();
const PORT = process.env.PORT || 3000;
const BASE_URL = (process.env.BASE_URL || `http://localhost:${PORT}`).replace(/\/$/, '');

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const DATA_DIR = path.join(__dirname, 'data');
const ORDERS_FILE = path.join(DATA_DIR, 'orders.json');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(ORDERS_FILE)) fs.writeFileSync(ORDERS_FILE, '[]');

const USERS_FILE = path.join(__dirname, 'users.txt');
function readUsers() {
  if (!fs.existsSync(USERS_FILE)) return [];
  const content = fs.readFileSync(USERS_FILE, 'utf8').trim();
  if (!content) return [];
  return content.split('\n').filter(Boolean).map((line) => {
    const [username, email, password, timestamp] = line.split('|');
    return { username, email, password, timestamp };
  });
}
app.post('/api/register', (req, res) => {
  const { username, email, password } = req.body;
  if (!username || !email || !password) return res.status(400).json({ success: false, message: 'Tüm alanları doldurun.' });
  if (!/^[^\s@]+@gmail\.com$/i.test(email)) return res.status(400).json({ success: false, message: 'Geçerli bir Gmail adresi girin.' });
  const existing = readUsers();
  if (existing.some((u) => u.username.toLowerCase() === username.toLowerCase())) return res.status(400).json({ success: false, message: 'Bu kullanıcı adı zaten alınmış.' });
  const timestamp = new Date().toISOString();
  fs.appendFileSync(USERS_FILE, `${username}|${email}|${password}|${timestamp}\n`, 'utf8');
  res.json({ success: true, message: 'Kayıt başarılı! Hoş geldiniz.' });
});
app.post('/api/login', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) return res.status(400).json({ success: false, message: 'Kullanıcı adı ve şifre gerekli.' });
  const user = readUsers().find((u) => u.username.toLowerCase() === username.toLowerCase() && u.password === password);
  if (!user) return res.status(401).json({ success: false, message: 'Kullanıcı adı veya şifre hatalı.' });
  res.json({ success: true, message: 'Giriş başarılı!', user: { username: user.username, email: user.email, timestamp: user.timestamp } });
});
app.get('/api/recent-users', (req, res) => {
  const all = readUsers();
  const users = all.slice(-5).reverse().map((u) => ({ username: u.username, timestamp: u.timestamp }));
  res.json({ users, total: all.length });
});


const PRODUCTS = {
  vip: {
    id: 'vip',
    name: 'VIP',
    priceTl: 100,
    group: process.env.VIP_GROUP || 'vip',
  },
  vipplus: {
    id: 'vipplus',
    name: 'VIP+',
    priceTl: 200,
    group: process.env.VIP_PLUS_GROUP || 'vipplus',
  },
};

function readOrders() {
  try { return JSON.parse(fs.readFileSync(ORDERS_FILE, 'utf8')); }
  catch { return []; }
}

function writeOrders(orders) {
  fs.writeFileSync(ORDERS_FILE, JSON.stringify(orders, null, 2));
}

function updateOrder(merchantOid, updater) {
  const orders = readOrders();
  const index = orders.findIndex(o => o.merchant_oid === merchantOid);
  if (index === -1) return null;
  orders[index] = updater(orders[index]);
  writeOrders(orders);
  return orders[index];
}

function getClientIp(req) {
  const forwarded = req.headers['x-forwarded-for'];
  if (forwarded) return String(forwarded).split(',')[0].trim();
  return req.socket.remoteAddress?.replace('::ffff:', '') || '127.0.0.1';
}

function safeMinecraftName(name) {
  const cleaned = String(name || '').trim();
  return /^[a-zA-Z0-9_]{3,16}$/.test(cleaned) ? cleaned : null;
}

function makeMerchantOid() {
  return 'CNW' + Date.now() + crypto.randomBytes(4).toString('hex').toUpperCase();
}

function makePaytrTokenForPayment({ merchant_id, user_ip, merchant_oid, email, payment_amount, user_basket, no_installment, max_installment, currency, test_mode }) {
  const hashStr = `${merchant_id}${user_ip}${merchant_oid}${email}${payment_amount}${user_basket}${no_installment}${max_installment}${currency}${test_mode}`;
  return crypto.createHmac('sha256', process.env.PAYTR_MERCHANT_KEY || '')
    .update(hashStr + (process.env.PAYTR_MERCHANT_SALT || ''))
    .digest('base64');
}

function verifyPaytrCallback(body) {
  const tokenStr = `${body.merchant_oid}${process.env.PAYTR_MERCHANT_SALT || ''}${body.status}${body.total_amount}`;
  const token = crypto.createHmac('sha256', process.env.PAYTR_MERCHANT_KEY || '')
    .update(tokenStr)
    .digest('base64');
  return token === body.hash;
}

async function giveMinecraftRank(order) {
  const command = `lp user ${order.minecraft_username} parent add ${order.product.group}`;

  if (String(process.env.RCON_ENABLED).toLowerCase() !== 'true') {
    return { executed: false, command, message: 'RCON_ENABLED=false olduğu için komut sadece hazırlandı.' };
  }

  const response = await sendRconCommand({
    host: process.env.RCON_HOST,
    port: process.env.RCON_PORT,
    password: process.env.RCON_PASSWORD,
    command,
  });

  return { executed: true, command, response };
}

app.get('/api/products', (req, res) => {
  res.json(Object.values(PRODUCTS).map(p => ({ id: p.id, name: p.name, priceTl: p.priceTl })));
});

app.post('/api/paytr/create-payment', async (req, res) => {
  try {
    const product = PRODUCTS[String(req.body.product || '').toLowerCase()];
    const username = safeMinecraftName(req.body.minecraft_username);
    const email = String(req.body.email || '').trim().toLowerCase();

    if (!product) return res.status(400).json({ error: 'Geçersiz ürün.' });
    if (!username) return res.status(400).json({ error: 'Minecraft kullanıcı adı 3-16 karakter olmalı. Sadece harf, sayı ve _ kullan.' });
    if (!/^\S+@\S+\.\S+$/.test(email)) return res.status(400).json({ error: 'Geçerli e-posta yaz.' });

    const merchant_id = process.env.PAYTR_MERCHANT_ID;
    if (!merchant_id || !process.env.PAYTR_MERCHANT_KEY || !process.env.PAYTR_MERCHANT_SALT) {
      return res.status(500).json({ error: 'PayTR bilgileri eksik. .env dosyasını doldur.' });
    }

    const merchant_oid = makeMerchantOid();
    const payment_amount = String(product.priceTl * 100);
    const user_basket = Buffer.from(JSON.stringify([[product.name, product.priceTl.toFixed(2), 1]])).toString('base64');
    const user_ip = getClientIp(req);
    const no_installment = '1';
    const max_installment = '0';
    const currency = 'TL';
    const test_mode = String(process.env.PAYTR_TEST_MODE || '1');

    const paytr_token = makePaytrTokenForPayment({
      merchant_id, user_ip, merchant_oid, email, payment_amount, user_basket,
      no_installment, max_installment, currency, test_mode,
    });

    const params = new URLSearchParams({
      merchant_id,
      user_ip,
      merchant_oid,
      email,
      payment_amount,
      paytr_token,
      user_basket,
      debug_on: String(process.env.PAYTR_DEBUG_ON || '1'),
      no_installment,
      max_installment,
      user_name: username,
      user_address: 'Minecraft sunucusu dijital ürün',
      user_phone: '05000000000',
      merchant_ok_url: `${BASE_URL}/payment-success.html?oid=${encodeURIComponent(merchant_oid)}`,
      merchant_fail_url: `${BASE_URL}/payment-fail.html?oid=${encodeURIComponent(merchant_oid)}`,
      timeout_limit: '30',
      currency,
      test_mode,
      lang: 'tr',
    });

    const paytrResponse = await fetch('https://www.paytr.com/odeme/api/get-token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: params,
    });

    const text = await paytrResponse.text();
    let data;
    try { data = JSON.parse(text); } catch { data = { status: 'failed', reason: text }; }

    if (data.status !== 'success') {
      return res.status(400).json({ error: data.reason || 'PayTR token alınamadı.', raw: data });
    }

    const orders = readOrders();
    orders.push({
      merchant_oid,
      status: 'pending',
      minecraft_username: username,
      email,
      product,
      expected_amount: payment_amount,
      paytr_total_amount: null,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      delivery: null,
    });
    writeOrders(orders);

    res.json({ token: data.token, merchant_oid });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Sunucu hatası: ' + err.message });
  }
});

app.post('/paytr/callback', async (req, res) => {
  try {
    const body = req.body;

    if (!verifyPaytrCallback(body)) {
      console.warn('PAYTR bad hash', body);
      return res.status(400).send('PAYTR notification failed: bad hash');
    }

    const orders = readOrders();
    const order = orders.find(o => o.merchant_oid === body.merchant_oid);
    if (!order) {
      console.warn('PAYTR unknown order', body.merchant_oid);
      return res.send('OK');
    }

    if (order.status === 'success' || order.status === 'failed') {
      return res.send('OK');
    }

    if (String(body.status) === 'success') {
      const paidAmount = String(body.total_amount || '');
      if (paidAmount !== String(order.expected_amount)) {
        updateOrder(order.merchant_oid, o => ({
          ...o,
          status: 'amount_mismatch',
          paytr_total_amount: paidAmount,
          updated_at: new Date().toISOString(),
          callback_raw: body,
        }));
        return res.send('OK');
      }

      let delivery;
      try {
        delivery = await giveMinecraftRank(order);
      } catch (err) {
        delivery = { executed: false, error: err.message };
      }

      updateOrder(order.merchant_oid, o => ({
        ...o,
        status: 'success',
        paytr_total_amount: paidAmount,
        updated_at: new Date().toISOString(),
        callback_raw: body,
        delivery,
      }));
    } else {
      updateOrder(order.merchant_oid, o => ({
        ...o,
        status: 'failed',
        failed_reason_code: body.failed_reason_code || null,
        failed_reason_msg: body.failed_reason_msg || null,
        updated_at: new Date().toISOString(),
        callback_raw: body,
      }));
    }

    res.send('OK');
  } catch (err) {
    console.error(err);
    // PayTR tekrar denesin diye OK dönmüyoruz.
    res.status(500).send('ERROR');
  }
});

app.get('/api/order/:oid', (req, res) => {
  const order = readOrders().find(o => o.merchant_oid === req.params.oid);
  if (!order) return res.status(404).json({ error: 'Sipariş bulunamadı.' });
  res.json({
    merchant_oid: order.merchant_oid,
    status: order.status,
    minecraft_username: order.minecraft_username,
    product: { name: order.product.name, priceTl: order.product.priceTl },
    delivery: order.delivery,
    created_at: order.created_at,
    updated_at: order.updated_at,
  });
});

app.listen(PORT, () => {
  console.log(`CyanideNW PayTR server: ${BASE_URL}`);
  console.log(`PayTR callback URL: ${BASE_URL}/paytr/callback`);
});
